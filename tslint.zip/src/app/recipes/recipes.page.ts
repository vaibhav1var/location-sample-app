import { Component, OnInit } from '@angular/core';
import { RecipesService } from './recipes.service';
import { Recipe } from './recipe.model';
import { Plugins, Capacitor } from '@capacitor/core';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.page.html',
  styleUrls: ['./recipes.page.scss'],
})

interface Coordinates {
  lat: number;
  lng: number;
}

export class RecipesPage implements OnInit {

  private recipes: Recipe[];


  constructor(private recipesService: RecipesService) { }

  ngOnInit() {
    this.recipes = this.recipesService.getAllRecipes();
  }

  private locateUser() {
    if (!Capacitor.isPluginAvailable('Geolocation')) {
      console.log('Error');
      return;
    }
    Plugins.Geolocation.getCurrentPosition()
      .then(geoPosition => {
        const coordinates: Coordinates = {
          lat: geoPosition.coords.latitude,
          lng: geoPosition.coords.longitude
        };
        console.log(coordinates);
      })
      .catch(err => {
        console.log('catch error');
      });
  }

}
